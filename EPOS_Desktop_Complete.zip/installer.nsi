
!define APPNAME "EPOS Desktop"
!define COMPANY "YourCompany"
!define DESCRIPTION "Fast Food EPOS System"
!define VERSION "1.0.0"
!define INSTALLDIR "$PROGRAMFILES\${COMPANY}\${APPNAME}"

OutFile "EPOS-Setup.exe"
InstallDir "${INSTALLDIR}"
ShowInstDetails show
ShowUninstDetails show
RequestExecutionLevel admin

Section "MainSection" SEC01
  SetOutPath "$INSTDIR"
  File "build\bin\epos-desktop.exe"
  File "license.json"
  CreateShortCut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\epos-desktop.exe"
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortCut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\epos-desktop.exe"
SectionEnd

Section "Uninstall"
  Delete "$INSTDIR\epos-desktop.exe"
  Delete "$INSTDIR\license.json"
  Delete "$DESKTOP\${APPNAME}.lnk"
  Delete "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"
  RMDir "$SMPROGRAMS\${APPNAME}"
  RMDir "$INSTDIR"
SectionEnd
