
package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"time"

	_ "github.com/mattn/go-sqlite3"
)

var db *sql.DB

func initDB() {
	var err error
	db, err = sql.Open("sqlite3", "./epos.db")
	if err != nil {
		log.Fatal(err)
	}

	createTables := `
	CREATE TABLE IF NOT EXISTS customers (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		name TEXT,
		phone TEXT,
		address TEXT
	);
	CREATE TABLE IF NOT EXISTS orders (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		customer_id INTEGER,
		total REAL,
		service_type TEXT,
		payment_method TEXT,
		datetime TEXT
	);
	CREATE TABLE IF NOT EXISTS order_items (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		order_id INTEGER,
		product_name TEXT,
		price REAL
	);`

	_, err = db.Exec(createTables)
	if err != nil {
		log.Fatal(err)
	}
	log.Println("Database initialized.")
}

type OrderRequest struct {
	CustomerName    string  `json:"customer_name"`
	CustomerPhone   string  `json:"customer_phone"`
	CustomerAddress string  `json:"customer_address"`
	Total           float64 `json:"total"`
	ServiceType     string  `json:"service_type"`
	PaymentMethod   string  `json:"payment_method"`
	Items           []struct {
		Name  string  `json:"name"`
		Price float64 `json:"price"`
	} `json:"items"`
}

func saveOrderHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}

	body, _ := ioutil.ReadAll(r.Body)
	defer r.Body.Close()

	var order OrderRequest
	err := json.Unmarshal(body, &order)
	if err != nil {
		http.Error(w, "Invalid data", http.StatusBadRequest)
		return
	}

	tx, err := db.Begin()
	if err != nil {
		http.Error(w, "DB error", http.StatusInternalServerError)
		return
	}

	// Insert customer
	res, err := tx.Exec("INSERT INTO customers (name, phone, address) VALUES (?, ?, ?)",
		order.CustomerName, order.CustomerPhone, order.CustomerAddress)
	if err != nil {
		tx.Rollback()
		http.Error(w, "Insert customer failed", http.StatusInternalServerError)
		return
	}
	customerID, _ := res.LastInsertId()

	// Insert order
	now := time.Now().Format("2006-01-02 15:04:05")
	res, err = tx.Exec("INSERT INTO orders (customer_id, total, service_type, payment_method, datetime) VALUES (?, ?, ?, ?, ?)",
		customerID, order.Total, order.ServiceType, order.PaymentMethod, now)
	if err != nil {
		tx.Rollback()
		http.Error(w, "Insert order failed", http.StatusInternalServerError)
		return
	}
	orderID, _ := res.LastInsertId()

	// Insert items
	for _, item := range order.Items {
		_, err = tx.Exec("INSERT INTO order_items (order_id, product_name, price) VALUES (?, ?, ?)",
			orderID, item.Name, item.Price)
		if err != nil {
			tx.Rollback()
			http.Error(w, "Insert item failed", http.StatusInternalServerError)
			return
		}
	}

	tx.Commit()
	fmt.Fprintln(w, "Order saved successfully.")
}
