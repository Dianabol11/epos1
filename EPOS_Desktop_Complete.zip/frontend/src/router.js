
import { createRouter, createWebHashHistory } from 'vue-router'

import OrderPage from './components/OrderPage.vue'
import AdminPage from './components/AdminPage.vue'
import CustomerPage from './components/CustomerPage.vue'
import PaymentPage from './components/PaymentPage.vue'
import LoginPage from './components/LoginPage.vue'

const routes = [
  { path: '/', redirect: '/login' },
  { path: '/login', component: LoginPage },
  { path: '/orders', component: OrderPage },
  { path: '/admin', component: AdminPage },
  { path: '/customers', component: CustomerPage },
  { path: '/payment', component: PaymentPage },
]

const router = createRouter({
  history: createWebHashHistory(),
  routes
})

export default router
