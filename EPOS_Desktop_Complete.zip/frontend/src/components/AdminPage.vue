
<template>
  <div class="admin-page">
    <h1>Admin Panel</h1>

    <h2>API Settings</h2>
    <form @submit.prevent="saveSettings">
      <div class="form-group">
        <label>Stripe Secret Key</label>
        <input v-model="stripeKey" type="text" />
      </div>
      <div class="form-group">
        <label>Twilio SID</label>
        <input v-model="twilioSID" type="text" />
      </div>
      <div class="form-group">
        <label>Twilio Auth Token</label>
        <input v-model="twilioToken" type="text" />
      </div>
      <div class="form-group">
        <label>Twilio From Number</label>
        <input v-model="twilioFrom" type="text" />
      </div>

      <button type="submit">Save Settings</button>
    </form>

    <div v-if="message" class="success-message">{{ message }}</div>
  </div>
</template>

<script>
export default {
  name: "AdminPage",
  data() {
    return {
      stripeKey: localStorage.getItem("STRIPE_SECRET_KEY") || "",
      twilioSID: localStorage.getItem("TWILIO_SID") || "",
      twilioToken: localStorage.getItem("TWILIO_AUTH_TOKEN") || "",
      twilioFrom: localStorage.getItem("TWILIO_FROM") || "",
      message: ""
    };
  },
  methods: {
    saveSettings() {
      localStorage.setItem("STRIPE_SECRET_KEY", this.stripeKey);
      localStorage.setItem("TWILIO_SID", this.twilioSID);
      localStorage.setItem("TWILIO_AUTH_TOKEN", this.twilioToken);
      localStorage.setItem("TWILIO_FROM", this.twilioFrom);
      this.message = "Settings saved successfully.";
    }
  }
};
</script>

<style scoped>
.admin-page {
  padding: 20px;
  max-width: 600px;
}
.form-group {
  margin-bottom: 15px;
}
.success-message {
  margin-top: 15px;
  color: green;
}
</style>
