
<template>
  <div class="payment-page">
    <h1>Payment</h1>

    <div class="payment-options">
      <label>
        <input type="radio" value="Cash" v-model="paymentMethod" />
        Cash
      </label>
      <label>
        <input type="radio" value="Card" v-model="paymentMethod" />
        Card
      </label>
      <label>
        <input type="radio" value="StripeLink" v-model="paymentMethod" />
        Pay by Link (Stripe)
      </label>
    </div>

    <div class="customer-info">
      <input v-model="name" placeholder="Customer Name" />
      <input v-model="phone" placeholder="Phone Number (e.g. +447911123456)" />
      <input v-model.number="amount" placeholder="Amount (£)" type="number" />
    </div>

    <div class="actions">
      <button @click="processPayment">Confirm Payment</button>
    </div>

    <div v-if="paymentMessage" class="payment-message">
      {{ paymentMessage }}
    </div>
  </div>
</template>

<script>
export default {
  name: "PaymentPage",
  data() {
    return {
      paymentMethod: "Cash",
      name: "",
      phone: "",
      amount: 0,
      paymentMessage: ""
    };
  },
  methods: {
    async processPayment() {
      if (!this.name || !this.phone || !this.amount) {
        this.paymentMessage = "Please enter customer name, phone and amount.";
        return;
      }

      if (this.paymentMethod === "StripeLink") {
        try {
          const response = await fetch("http://localhost:8080/api/send-payment-link", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              name: this.name,
              phone: this.phone,
              amount: this.amount
            })
          });

          if (response.ok) {
            const text = await response.text();
            this.paymentMessage = text;
          } else {
            this.paymentMessage = "Failed to send Stripe payment link.";
          }
        } catch (err) {
          this.paymentMessage = "Error sending request: " + err.message;
        }
      } else {
        this.paymentMessage = "Payment confirmed: " + this.paymentMethod;
      }
    }
  }
};
</script>

<style scoped>
.payment-page {
  padding: 20px;
}
.payment-options label {
  display: block;
  margin-bottom: 10px;
}
.customer-info input {
  display: block;
  margin: 10px 0;
  padding: 8px;
  width: 100%;
}
.actions {
  margin-top: 20px;
}
.payment-message {
  margin-top: 20px;
  color: green;
  font-weight: bold;
}
</style>
