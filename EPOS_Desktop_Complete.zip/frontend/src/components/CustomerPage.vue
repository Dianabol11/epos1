
<template>
  <div class="customer-page">
    <h1>Customer Information</h1>

    <form @submit.prevent="saveCustomer">
      <div class="form-group">
        <label for="name">Name:</label>
        <input v-model="name" type="text" id="name" required />
      </div>

      <div class="form-group">
        <label for="phone">Phone:</label>
        <input v-model="phone" type="tel" id="phone" required />
      </div>

      <div class="form-group">
        <label for="address">Address:</label>
        <textarea v-model="address" id="address" required></textarea>
      </div>

      <button type="submit">Save Customer</button>
    </form>

    <div v-if="message" class="success-message">
      {{ message }}
    </div>
  </div>
</template>

<script>
export default {
  name: "CustomerPage",
  data() {
    return {
      name: "",
      phone: "",
      address: "",
      message: ""
    };
  },
  methods: {
    saveCustomer() {
      if (this.name && this.phone && this.address) {
        // Gelecekte API'ye gönderilebilir
        this.message = "Customer information saved successfully.";
      } else {
        this.message = "Please fill all fields.";
      }
    }
  }
};
</script>

<style scoped>
.customer-page {
  padding: 20px;
  max-width: 500px;
}
.form-group {
  margin-bottom: 15px;
}
.success-message {
  margin-top: 15px;
  color: green;
}
</style>
