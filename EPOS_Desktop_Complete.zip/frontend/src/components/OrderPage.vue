
<template>
  <div class="order-page">
    <h1>Order Page</h1>

    <div class="category-menu">
      <button v-for="cat in categories" :key="cat" @click="selectCategory(cat)">
        {{ cat }}
      </button>
    </div>

    <div class="product-list">
      <div
        v-for="item in filteredProducts"
        :key="item.id"
        class="product-item"
        @click="addToCart(item)"
      >
        {{ item.name }} - £{{ item.price.toFixed(2) }}
      </div>
    </div>

    <div class="cart">
      <h3>Cart</h3>
      <div v-for="(item, index) in cart" :key="index">
        {{ item.name }} - £{{ item.price.toFixed(2) }}
      </div>
      <p>Total: £{{ total.toFixed(2) }}</p>

      <div class="delivery-type">
        <label><input type="radio" value="Delivery" v-model="serviceType" /> Delivery</label>
        <label><input type="radio" value="Collection" v-model="serviceType" /> Collection</label>
      </div>

      <div class="customer-info">
        <input v-model="customerName" placeholder="Customer Name" />
        <input v-model="customerPhone" placeholder="Phone" />
        <input v-model="customerAddress" placeholder="Address" />
      </div>

      <button @click="submitOrder">Complete Order</button>
      <div v-if="message" class="order-message">{{ message }}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "OrderPage",
  data() {
    return {
      categories: ["Pizza", "Burger", "Drinks"],
      selectedCategory: "Pizza",
      products: [
        { id: 1, name: "Margherita Pizza", price: 8.99, category: "Pizza" },
        { id: 2, name: "Pepperoni Pizza", price: 9.99, category: "Pizza" },
        { id: 3, name: "Cheeseburger", price: 6.49, category: "Burger" },
        { id: 4, name: "Cola", price: 1.99, category: "Drinks" }
      ],
      cart: [],
      serviceType: "Delivery",
      customerName: "",
      customerPhone: "",
      customerAddress: "",
      message: ""
    };
  },
  computed: {
    filteredProducts() {
      return this.products.filter(p => p.category === this.selectedCategory);
    },
    total() {
      return this.cart.reduce((sum, item) => sum + item.price, 0);
    }
  },
  methods: {
    selectCategory(cat) {
      this.selectedCategory = cat;
    },
    addToCart(item) {
      this.cart.push(item);
    },
    async submitOrder() {
      if (!this.customerName || !this.customerPhone || !this.customerAddress || this.cart.length === 0) {
        this.message = "Please fill all fields and add at least one product.";
        return;
      }

      const payload = {
        customer_name: this.customerName,
        customer_phone: this.customerPhone,
        customer_address: this.customerAddress,
        total: this.total,
        service_type: this.serviceType,
        payment_method: "Unpaid",
        items: this.cart.map(p => ({ name: p.name, price: p.price }))
      };

      try {
        const res = await fetch("http://localhost:8080/api/save-order", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
        });
        const text = await res.text();
        this.message = text;
        if (res.ok) this.cart = [];
      } catch (err) {
        this.message = "Error: " + err.message;
      }
    }
  }
};
</script>

<style scoped>
.order-page {
  display: flex;
  flex-direction: column;
  padding: 20px;
}
.category-menu button {
  margin-right: 10px;
}
.product-list {
  margin-top: 20px;
  display: flex;
  gap: 10px;
}
.product-item {
  border: 1px solid #ccc;
  padding: 10px;
  cursor: pointer;
}
.cart {
  margin-top: 30px;
  border-top: 1px solid #ccc;
  padding-top: 20px;
}
.delivery-type {
  margin-top: 10px;
}
.customer-info input {
  display: block;
  margin-top: 10px;
  padding: 6px;
  width: 100%;
}
.order-message {
  margin-top: 10px;
  color: green;
}
</style>
