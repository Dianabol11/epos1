
<template>
  <div class="login-page">
    <h1>Login</h1>

    <div class="form-group">
      <label for="pin">Enter PIN:</label>
      <input
        id="pin"
        v-model="pin"
        type="password"
        placeholder="****"
        @keyup.enter="checkPIN"
      />
    </div>

    <button @click="checkPIN">Login</button>

    <div v-if="errorMessage" class="error-message">
      {{ errorMessage }}
    </div>
  </div>
</template>

<script>
export default {
  name: "LoginPage",
  data() {
    return {
      pin: "",
      errorMessage: ""
    };
  },
  methods: {
    checkPIN() {
      const validPIN = "1234"; // Daha sonra admin panelden değiştirilebilir
      if (this.pin === validPIN) {
        this.$router.push("/orders");
      } else {
        this.errorMessage = "Incorrect PIN. Try again.";
        this.pin = "";
      }
    }
  }
};
</script>

<style scoped>
.login-page {
  padding: 40px;
  max-width: 400px;
}
.form-group {
  margin-bottom: 20px;
}
.error-message {
  color: red;
  margin-top: 10px;
}
</style>
