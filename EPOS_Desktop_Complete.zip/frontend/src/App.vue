
<template>
  <div id="app">
    <nav>
      <router-link to="/orders">Orders</router-link> |
      <router-link to="/admin">Admin</router-link> |
      <router-link to="/customers">Customers</router-link> |
      <router-link to="/payment">Payment</router-link>
    </nav>
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
nav {
  background: #eee;
  padding: 10px;
}
nav a {
  margin: 0 10px;
}
</style>
