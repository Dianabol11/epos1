
package main

import (
	"bufio"
	"fmt"
	"log"
	"net/http"
	"strings"
	"sync"
	"time"

	"go.bug.st/serial"
)

var lastCallerID string
var cidMutex sync.Mutex

func startCallerIDReader(portName string) {
	mode := &serial.Mode{
		BaudRate: 9600,
	}
	port, err := serial.Open(portName, mode)
	if err != nil {
		log.Println("Caller ID device not found:", err)
		return
	}

	log.Println("Caller ID listening on", portName)
	reader := bufio.NewReader(port)

	for {
		line, err := reader.ReadString('
')
		if err != nil {
			log.Println("Error reading from serial:", err)
			time.Sleep(2 * time.Second)
			continue
		}
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "CID:") {
			number := strings.TrimPrefix(line, "CID:")
			log.Println("Incoming Call from:", number)
			cidMutex.Lock()
			lastCallerID = number
			cidMutex.Unlock()
		}
	}
}

func getLastCallerHandler(w http.ResponseWriter, r *http.Request) {
	cidMutex.Lock()
	defer cidMutex.Unlock()
	w.Header().Set("Content-Type", "application/json")
	fmt.Fprintf(w, `{"caller":"%s"}`, lastCallerID)
}
