
package main

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"net/http"
	"time"
)

type ZReport struct {
	TotalSales        float64            `json:"total_sales"`
	ByPaymentMethod   map[string]float64 `json:"by_payment_method"`
	ByServiceType     map[string]float64 `json:"by_service_type"`
	ProductSales      map[string]float64 `json:"product_sales"`
	TransactionCount  int                `json:"transaction_count"`
}

func zReportHandler(w http.ResponseWriter, r *http.Request) {
	today := time.Now().Format("2006-01-02")
	rows, err := db.Query(`
		SELECT o.payment_method, o.service_type, oi.product_name, oi.price
		FROM orders o
		JOIN order_items oi ON o.id = oi.order_id
		WHERE o.datetime LIKE ? || '%'`, today)
	if err != nil {
		http.Error(w, "DB error", http.StatusInternalServerError)
		return
	}
	defer rows.Close()

	report := ZReport{
		ByPaymentMethod: make(map[string]float64),
		ByServiceType:   make(map[string]float64),
		ProductSales:    make(map[string]float64),
	}

	var paymentMethod, serviceType, productName string
	var price float64

	for rows.Next() {
		err = rows.Scan(&paymentMethod, &serviceType, &productName, &price)
		if err != nil {
			continue
		}
		report.TotalSales += price
		report.ByPaymentMethod[paymentMethod] += price
		report.ByServiceType[serviceType] += price
		report.ProductSales[productName] += price
		report.TransactionCount++
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(report)
}
