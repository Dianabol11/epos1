
package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"strings"
)

type PaymentRequest struct {
	Name   string  `json:"name"`
	Phone  string  `json:"phone"`
	Amount float64 `json:"amount"`
}

func sendPaymentLinkHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Only POST allowed", http.StatusMethodNotAllowed)
		return
	}

	var req PaymentRequest
	body, err := ioutil.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Invalid request", http.StatusBadRequest)
		return
	}
	defer r.Body.Close()

	err = json.Unmarshal(body, &req)
	if err != nil {
		http.Error(w, "Bad JSON", http.StatusBadRequest)
		return
	}

	stripeKey := os.Getenv("STRIPE_SECRET_KEY")
	twilioSID := os.Getenv("TWILIO_SID")
	twilioToken := os.Getenv("TWILIO_AUTH_TOKEN")
	twilioFrom := os.Getenv("TWILIO_FROM")

	if stripeKey == "" || twilioSID == "" || twilioToken == "" || twilioFrom == "" {
		http.Error(w, "Missing API keys", http.StatusInternalServerError)
		return
	}

	// Stripe Payment Link (simplified example)
	stripeLink := fmt.Sprintf("https://buy.stripe.com/test_4gw4hY7Ucbn6e3e3cc?amount=%.2f", req.Amount)

	// Send SMS using Twilio
	msgData := fmt.Sprintf("To=%s&From=%s&Body=%s", req.Phone, twilioFrom, "Payment link: "+stripeLink)
	reqBody := strings.NewReader(msgData)

	twilioURL := fmt.Sprintf("https://api.twilio.com/2010-04-01/Accounts/%s/Messages.json", twilioSID)
	client := &http.Client{}
	twilioReq, _ := http.NewRequest("POST", twilioURL, reqBody)
	twilioReq.SetBasicAuth(twilioSID, twilioToken)
	twilioReq.Header.Add("Content-Type", "application/x-www-form-urlencoded")

	resp, err := client.Do(twilioReq)
	if err != nil {
		http.Error(w, "Failed to send SMS", http.StatusInternalServerError)
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 200 && resp.StatusCode < 300 {
		w.Write([]byte("Payment link sent successfully."))
	} else {
		http.Error(w, "Failed to send SMS", http.StatusInternalServerError)
	}
}
