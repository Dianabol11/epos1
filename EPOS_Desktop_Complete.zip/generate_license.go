
package main

import (
	"encoding/json"
	"fmt"
	"net"
	"os"
	"time"
)

type License struct {
	Key         string `json:"key"`
	Expires     string `json:"expires"`
	LastChecked string `json:"last_checked"`
	FailCount   int    `json:"fail_count"`
}

func main() {
	id := getSystemID()
	license := License{
		Key:         id,
		Expires:     "2025-06-30",
		LastChecked: time.Now().Format("2006-01-02"),
		FailCount:   0,
	}
	data, _ := json.MarshalIndent(license, "", "  ")
	err := os.WriteFile("license.json", data, 0644)
	if err != nil {
		fmt.Println("Dosya yazılamadı:", err)
		return
	}
	fmt.Println("Lisans dosyası başarıyla oluşturuldu.")
	fmt.Println("Sistem Kimliği (Key):", id)
}

func getSystemID() string {
	ifaces, err := net.Interfaces()
	if err != nil || len(ifaces) == 0 {
		return "UNKNOWN"
	}
	return ifaces[0].HardwareAddr.String()
}
