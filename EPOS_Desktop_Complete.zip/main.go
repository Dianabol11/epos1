package main

import (
	"net/http"
	"log"
	"embed"

	"github.com/wailsapp/wails/v2"
	"github.com/wailsapp/wails/v2/pkg/options"
	"github.com/wailsapp/wails/v2/pkg/options/assetserver"
	"github.com/wailsapp/wails/v2/pkg/options/mac"
)

//go:embed all:frontend/dist
var assets embed.FS

func main() {
	err := checkLicense()
	if err != nil {
		log.Fatal("License error:", err)
	}
	go startCallerIDReader("COM3") // COM port adı burada ayarlanmalı
	http.HandleFunc("/api/last-caller", getLastCallerHandler)
	http.HandleFunc("/api/z-report", zReportHandler)

	initDB()
	http.HandleFunc("/api/send-payment-link", sendPaymentLinkHandler)
	http.HandleFunc("/api/save-order", saveOrderHandler)
	log.Println("Backend API listening on http://localhost:8080")
	go http.ListenAndServe(":8080", nil)

	// Create an instance of the app structure
	app := NewApp()

	// Create application with options
	err := wails.Run(&options.App{
		Title:  "EPOS Data Portal Installer",
		Width:  1400,
		Height: 900,
		AssetServer: &assetserver.Options{
			Assets: assets,
		},
		BackgroundColour: &options.RGBA{R: 0, G: 0, B: 0, A: 0},
		OnStartup:        app.startup,
		Bind: []interface{}{
			app,
		},
		// Remove white flicker on startup (Mac only)
		Mac: &mac.Options{
			WebviewIsTransparent: true,
		},
	})

	if err != nil {
		println("Error:", err.Error())
	}
}
