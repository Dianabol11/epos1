
// +build windows

package main

import (
	"encoding/json"
	"fmt"
	"log"
	"net/http"
	"strings"

	"github.com/alexbrainman/printer"
)

type PrintRequest struct {
	CustomerName    string  `json:"customer_name"`
	CustomerPhone   string  `json:"customer_phone"`
	CustomerAddress string  `json:"customer_address"`
	Items           []struct {
		Name  string  `json:"name"`
		Price float64 `json:"price"`
	} `json:"items"`
	Total        float64 `json:"total"`
	ServiceType  string  `json:"service_type"`
	PaymentMethod string `json:"payment_method"`
}

func printReceiptHandler(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}

	var req PrintRequest
	err := json.NewDecoder(r.Body).Decode(&req)
	if err != nil {
		http.Error(w, "Invalid JSON", http.StatusBadRequest)
		return
	}

	printText := generateReceiptText(req)

	p, err := printer.Open("POS Printer")
	if err != nil {
		http.Error(w, "Failed to open printer: "+err.Error(), http.StatusInternalServerError)
		return
	}
	defer p.Close()

	_, err = p.Write([]byte(printText))
	if err != nil {
		http.Error(w, "Failed to print: "+err.Error(), http.StatusInternalServerError)
		return
	}

	fmt.Fprintln(w, "Receipt sent to printer successfully.")
}

func generateReceiptText(req PrintRequest) string {
	var b strings.Builder
	b.WriteString("==== RECEIPT ====
")
	b.WriteString("Customer: " + req.CustomerName + "\n")
	b.WriteString("Phone: " + req.CustomerPhone + "\n")
	b.WriteString("Address: " + req.CustomerAddress + "\n")
	b.WriteString("Service: " + req.ServiceType + " | Payment: " + req.PaymentMethod + "\n")
	b.WriteString("-----------------
")
	for _, item := range req.Items {
		b.WriteString(fmt.Sprintf("%-20s £%.2f\n", item.Name, item.Price))
	}
	b.WriteString("-----------------
")
	b.WriteString(fmt.Sprintf("TOTAL:           £%.2f\n", req.Total))
	b.WriteString("=================

")
	return b.String()
}
