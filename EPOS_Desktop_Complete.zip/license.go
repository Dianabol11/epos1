
package main

import (
	"encoding/json"
	"errors"
	"fmt"
	"log"
	"net"
	"os"
	"time"
)

type License struct {
	Key         string `json:"key"`
	Expires     string `json:"expires"`
	LastChecked string `json:"last_checked"`
	FailCount   int    `json:"fail_count"`
}

var licensePath = "./license.json"

func getSystemID() string {
	ifaces, err := net.Interfaces()
	if err != nil || len(ifaces) == 0 {
		return "UNKNOWN"
	}
	return ifaces[0].HardwareAddr.String()
}

func checkLicense() error {
	data, err := os.ReadFile(licensePath)
	if err != nil {
		return errors.New("license file not found")
	}

	var lic License
	err = json.Unmarshal(data, &lic)
	if err != nil {
		return errors.New("invalid license format")
	}

	now := time.Now()
	expiry, err := time.Parse("2006-01-02", lic.Expires)
	if err != nil {
		return errors.New("invalid license date")
	}

	if now.After(expiry) {
		return errors.New("license expired")
	}

	lastChecked, _ := time.Parse("2006-01-02", lic.LastChecked)
	if now.Before(lastChecked) {
		lic.FailCount++
		log.Println("System clock appears to have been tampered with.")
		if lic.FailCount >= 3 {
			return errors.New("license locked due to time manipulation")
		}
	} else {
		lic.FailCount = 0
	}

	lic.LastChecked = now.Format("2006-01-02")
	updated, _ := json.MarshalIndent(lic, "", "  ")
	_ = os.WriteFile(licensePath, updated, 0644)

	return nil
}
