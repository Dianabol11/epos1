@echo off
echo [1/4] Frontend derleniyor...
cd frontend
call npm install
call npm run build
cd ..

echo [2/4] Wails build başlatılıyor...
call wails build

if %ERRORLEVEL% NEQ 0 (
    echo Wails build başarısız oldu.
    pause
    exit /b 1
)

echo [3/4] license.json kontrol ediliyor...
if not exist license.json (
    echo HATA: license.json bulunamadı!
    pause
    exit /b 1
)

echo [4/4] NSIS ile installer oluşturuluyor...
makensis installer.nsi

if %ERRORLEVEL% NEQ 0 (
    echo Installer oluşturulamadı.
    pause
    exit /b 1
)

echo Başarıyla tamamlandı. EPOS-Setup.exe hazır!
pause
